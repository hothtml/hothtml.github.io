#version:emlog 5.3.1
#date:2014-11-21 21:14
#tableprefix:emlog_
DROP TABLE IF EXISTS emlog_attachment;
CREATE TABLE `emlog_attachment` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blogid` int(10) unsigned NOT NULL DEFAULT '0',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `filesize` int(10) NOT NULL DEFAULT '0',
  `filepath` varchar(255) NOT NULL DEFAULT '',
  `addtime` bigint(20) NOT NULL DEFAULT '0',
  `width` int(10) NOT NULL DEFAULT '0',
  `height` int(10) NOT NULL DEFAULT '0',
  `mimetype` varchar(40) NOT NULL DEFAULT '',
  `thumfor` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `blogid` (`blogid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS emlog_blog;
CREATE TABLE `emlog_blog` (
  `gid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL,
  `content` longtext NOT NULL,
  `excerpt` longtext NOT NULL,
  `alias` varchar(200) NOT NULL DEFAULT '',
  `author` int(10) NOT NULL DEFAULT '1',
  `sortid` int(10) NOT NULL DEFAULT '-1',
  `type` varchar(20) NOT NULL DEFAULT 'blog',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `comnum` int(10) unsigned NOT NULL DEFAULT '0',
  `attnum` int(10) unsigned NOT NULL DEFAULT '0',
  `top` enum('n','y') NOT NULL DEFAULT 'n',
  `sortop` enum('n','y') NOT NULL DEFAULT 'n',
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  `checked` enum('n','y') NOT NULL DEFAULT 'y',
  `allow_remark` enum('n','y') NOT NULL DEFAULT 'y',
  `password` varchar(255) NOT NULL DEFAULT '',
  `template` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`),
  KEY `date` (`date`),
  KEY `author` (`author`),
  KEY `sortid` (`sortid`),
  KEY `type` (`type`),
  KEY `views` (`views`),
  KEY `comnum` (`comnum`),
  KEY `hide` (`hide`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO emlog_blog VALUES('4','如何让设计效果可量化','1416570562','<a style=\"text-transform:none;background-color:#ffffff;text-indent:0px;font:12px Tahoma, \'Hiragino Sans Gb\', \'Microsoft YaHei\';white-space:normal;letter-spacing:normal;color:#333333;word-spacing:0px;text-decoration:none;-webkit-text-stroke-width:0px;\" href=\"http://cdc.tencent.com/?p=8118\"><img style=\"border-bottom:medium none;border-left:medium none;padding-bottom:0px;margin:0px;padding-left:0px;padding-right:0px;float:left;border-top:medium none;border-right:medium none;padding-top:0px;\" src=\"http://cdc.tencent.com/wp-content/uploads/2014/07/%E8%AE%BE%E8%AE%A1%E9%87%8F%E5%8C%96banner.jpg\" /></a><span style=\"text-transform:none;background-color:#ffffff;text-indent:0px;display:inline !important;font:12px Tahoma, \'Hiragino Sans Gb\', \'Microsoft YaHei\';white-space:normal;float:none;letter-spacing:normal;color:#333333;word-spacing:0px;-webkit-text-stroke-width:0px;\"></span> \r\n<div style=\"position:relative;padding-bottom:17px;text-transform:none;text-indent:0px;margin:0px;padding-left:0px;width:720px;padding-right:0px;font:14px/24px Tahoma, \'Hiragino Sans Gb\', \'Microsoft YaHei\';white-space:normal;background:url(http://cdc.tencent.com/wp-content/themes/cdcblog2/images/hatching_line.png) #ffffff repeat-x;letter-spacing:normal;color:#333333;clear:both;overflow:hidden;word-spacing:0px;padding-top:17px;-webkit-text-stroke-width:0px;\" class=\"text\">\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		前言:\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		做搜搜这些年一直沉浸于重点工作中的项目，除了定时写项目总结与培训。都快忘记写文章很抱歉。这次终于有了重新学习机会，2014年应该多写。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		长久一来也是思考如何让我们每天面对的工作内容更直观价值体现与量化。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		做为搜索交互设计师。更正，做为搜索用户体验设计师，如何将你的技能和除网站之外背景知识运用到搜索设计工作中去–这也正是大多数用户体验真正开始的地方。<span id=\"more-8118\"></span>\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		想到搜索的设计，就是搜索还需要设计?或是搜索不就一个框加按钮.让视觉做的好看些不就好了!其实交互设计师，视觉设计师，开发人员，信息架构师，搜索引擎优化专业人员以及WEB分析师都因为各自有着独立技能体现出各身在于搜索类产品的价值。那作为合格设计师我们不仅需要是知识，技能，经验，创新等，同时我们也需要具备体现设计工作价值的方法。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		&nbsp;\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		记得在项目不断迭代优化过程中，设计师们也总说我们价值不被认可。当时需求方与老板也常问我你们设计究竟能否可量化如何可量化？当然先不说其它因果原由与价值其它体现。本身这个问题也是我长久一来一直思考刚好借此将它解决。当时也找团队讨论听到大家纷纷提到设计太抽象与设计很难通过数据量化等…其实在这个探讨过程也是发现问题所在过程，把大家疑虑问题点归纳然后逐个分析并且思考解决后再归纳梳出。然后在实战过程中再不断调整与持续再归纳思考。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		简单如下：\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		&nbsp;\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		<span style=\"font-weight:bolder;\">首先，我们做项目的交互设计可量化是需要一个基本评估标准</span>：\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		个人认为根据不同项目侧重会有所不同，这个需要设计师根据项目需求和产品目标等来判断。任何纬度与标准都是参考，随着个人和行业发展与变化一定都是时时变通。所以没有固定标准走天下或者说标准也是时时更新中。\r\n	</p>\r\n	<ol style=\"padding-bottom:0px;list-style-type:none;margin:0px;padding-left:0px;padding-right:0px;padding-top:0px;\">\r\n		<li style=\"padding-bottom:0px;margin:0px;padding-left:0px;padding-right:0px;padding-top:0px;\">\r\n			<span style=\"font-weight:bolder;\">1.项目功能设计</span>。\r\n		</li>\r\n	</ol>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		–&nbsp;点击率、转化率、点击流、活跃度、留存率、成功率等\r\n	</p>\r\n	<ol style=\"padding-bottom:0px;list-style-type:none;margin:0px;padding-left:0px;padding-right:0px;padding-top:0px;\" start=\"2\">\r\n		<li style=\"padding-bottom:0px;margin:0px;padding-left:0px;padding-right:0px;padding-top:0px;\">\r\n			<span style=\"font-weight:bolder;\">2.体验可用性</span>。\r\n		</li>\r\n	</ol>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		识别性-&nbsp;点击率\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		高效性-&nbsp;时间效率\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		有效性-&nbsp;功能使用成功率、操作信息传达有效性\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		易学性-&nbsp;新用户操作与操作的符合程度\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		一致性-&nbsp;和规范不一致数量\r\n	</p>\r\n	<ol style=\"padding-bottom:0px;list-style-type:none;margin:0px;padding-left:0px;padding-right:0px;padding-top:0px;\" start=\"3\">\r\n		<li style=\"padding-bottom:0px;margin:0px;padding-left:0px;padding-right:0px;padding-top:0px;\">\r\n			<span style=\"font-weight:bolder;\">3.用户满意度</span>。\r\n		</li>\r\n	</ol>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		–&nbsp;口碑、新增用户数、在线时长、回头率等\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		&nbsp;\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		<span style=\"font-weight:bolder;\">其次，根据基本评估标准进行评估可量化</span>：\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		每个项目根据需求设计都有所不同，搜搜在做网页改版时候我们有比较突出预览功能，左边栏等。当时我以A/B&nbsp;Test,&nbsp;灰度测试做为主要数据评估方法。在预览新产品没有参照物时候，其实建议可用按我们预期标准来进行对比。相反则以同时与旧版本进行对比。\r\n	</p>\r\n	<ol style=\"padding-bottom:0px;list-style-type:none;margin:0px;padding-left:0px;padding-right:0px;padding-top:0px;\">\r\n		<li style=\"padding-bottom:0px;margin:0px;padding-left:0px;padding-right:0px;padding-top:0px;\">\r\n			<span style=\"font-weight:bolder;\">1.数据统计和分析。</span>\r\n		</li>\r\n	</ol>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		-采用数据指标有：点击率、转化率、点击流、活跃度、留存率、成功率等。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		&nbsp;\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		1)&nbsp; 举例：以网页预览点击率分析\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		预览适合评价纬度<br />\r\n功能需求、识别性\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		统计方法<br />\r\n点击次数/曝光量\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		参照物<br />\r\n上线前后一周或者一月的日均同比<br />\r\nAB测试的方式，两个方案之间比较<br />\r\n干扰因素\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		同比的方式，不适合单独评估内容型模块的设计效果，用户点击的决策受内容本身影响较大。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		2)&nbsp; 举例：以点击流分析\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		适合评价纬度\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		有效性\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		统计方法\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		页面跳转的持续点击流统计\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		参照物\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		上线前后一周或者一月的日均同比\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		AB测试的方式，两个方案之间比较\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		干扰因素\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		同比的方式，会受不同时间段内其他相关因素的干扰。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		……\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		转化率在做搜搜首页改版时做为数据指标给出很好的评估参考。活跃度与留存率均在预览功能设计同时做为很重要的数据评估指标。成功率在需要用户配合注册或填写内容时等也都可以做为其一参考。以上是做为搜搜为纬度的数据基本标准参考内容。个人始终把数据做为客观决定之一，并非唯一。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		&nbsp;\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		2.&nbsp;<span style=\"font-weight:bolder;\">用户研究</span>。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		–&nbsp;用户访谈、问卷调查、产品反馈满意度、可用性测试\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		用户研究比较适用于搜搜需求挖掘和新方案的评估，可用性测试主要分为两类：\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		1)&nbsp;&nbsp;&nbsp;&nbsp;总结性评估：版本更新时，评估旧版本，可以给与新版本以设计指导，并且作为新版本上线后的比较依据。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		2)&nbsp;&nbsp;&nbsp;&nbsp;设计中评估：用设计Demo或灰度上线，找用户测试，目的是发现问题，在产品完全上线之前更加完善产品。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		&nbsp;\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		3.&nbsp;<span style=\"font-weight:bolder;\">专家评估</span>。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		大家在探讨过程中提到最多，其实我很犹豫要不要写上这个点。专家评估的权威性和产品形态了解程度都会受限。因为没有完善标准可以普及到每个对应背景设计环境中。当然经验很重要，所以在评估过程中可以给以很好的建议。另外就是站在其他角度去看体验闭环。但建议不要做为可量化硬性参考。\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		&nbsp;\r\n	</p>\r\n	<p style=\"padding-bottom:7px;margin:0px;padding-left:0px;width:720px;padding-right:0px;clear:both;padding-top:7px;\">\r\n		以上是简单归纳的几个思考点,如前面提到归纳实战后再不断思考归纳。搜索产品常常让设计工作价值更值得长期思考并挖掘。越是简单越值得挖掘。或许数据增长也不代表设计质量一定就是最好。再或者我们不仅把本身做为参照对比数据 ，同时与行内对比数据又如何更好挖掘。确定工作成效的评估纬度和评估指标不管是否可度量，都是我们设计师值得去思考与挖掘必经之路。\r\n	</p>\r\n</div>\r\n<p>\r\n	&nbsp;\r\n</p>','','','1','-1','blog','19','0','0','n','n','n','y','y','','');

DROP TABLE IF EXISTS emlog_comment;
CREATE TABLE `emlog_comment` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(10) unsigned NOT NULL DEFAULT '0',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `date` bigint(20) NOT NULL,
  `poster` varchar(20) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `mail` varchar(60) NOT NULL DEFAULT '',
  `url` varchar(75) NOT NULL DEFAULT '',
  `ip` varchar(128) NOT NULL DEFAULT '',
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`cid`),
  KEY `gid` (`gid`),
  KEY `date` (`date`),
  KEY `hide` (`hide`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS emlog_options;
CREATE TABLE `emlog_options` (
  `option_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(255) NOT NULL,
  `option_value` longtext NOT NULL,
  PRIMARY KEY (`option_id`),
  KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

INSERT INTO emlog_options VALUES('1','blogname','');
INSERT INTO emlog_options VALUES('2','bloginfo','');
INSERT INTO emlog_options VALUES('3','site_title','');
INSERT INTO emlog_options VALUES('4','site_description','');
INSERT INTO emlog_options VALUES('5','site_key','emlog');
INSERT INTO emlog_options VALUES('6','log_title_style','1');
INSERT INTO emlog_options VALUES('7','blogurl','http://aimidada.com/');
INSERT INTO emlog_options VALUES('8','icp','');
INSERT INTO emlog_options VALUES('9','footer_info','');
INSERT INTO emlog_options VALUES('10','admin_perpage_num','15');
INSERT INTO emlog_options VALUES('11','rss_output_num','0');
INSERT INTO emlog_options VALUES('12','rss_output_fulltext','y');
INSERT INTO emlog_options VALUES('13','index_lognum','10');
INSERT INTO emlog_options VALUES('14','index_comnum','10');
INSERT INTO emlog_options VALUES('15','index_twnum','10');
INSERT INTO emlog_options VALUES('16','index_newtwnum','5');
INSERT INTO emlog_options VALUES('17','index_newlognum','5');
INSERT INTO emlog_options VALUES('18','index_randlognum','5');
INSERT INTO emlog_options VALUES('19','index_hotlognum','5');
INSERT INTO emlog_options VALUES('20','comment_subnum','20');
INSERT INTO emlog_options VALUES('21','nonce_templet','default');
INSERT INTO emlog_options VALUES('22','admin_style','default');
INSERT INTO emlog_options VALUES('23','tpl_sidenum','1');
INSERT INTO emlog_options VALUES('24','comment_code','n');
INSERT INTO emlog_options VALUES('25','comment_needchinese','y');
INSERT INTO emlog_options VALUES('26','comment_interval','60');
INSERT INTO emlog_options VALUES('27','isgravatar','y');
INSERT INTO emlog_options VALUES('28','isthumbnail','y');
INSERT INTO emlog_options VALUES('29','att_maxsize','20480');
INSERT INTO emlog_options VALUES('30','att_type','rar,zip,gif,jpg,jpeg,png,txt,pdf,docx,doc,xls,xlsx');
INSERT INTO emlog_options VALUES('31','att_imgmaxw','420');
INSERT INTO emlog_options VALUES('32','att_imgmaxh','460');
INSERT INTO emlog_options VALUES('33','comment_paging','y');
INSERT INTO emlog_options VALUES('34','comment_pnum','10');
INSERT INTO emlog_options VALUES('35','comment_order','newer');
INSERT INTO emlog_options VALUES('36','login_code','n');
INSERT INTO emlog_options VALUES('37','reply_code','n');
INSERT INTO emlog_options VALUES('38','iscomment','y');
INSERT INTO emlog_options VALUES('39','ischkcomment','y');
INSERT INTO emlog_options VALUES('40','ischkreply','n');
INSERT INTO emlog_options VALUES('41','isurlrewrite','3');
INSERT INTO emlog_options VALUES('42','isalias','y');
INSERT INTO emlog_options VALUES('43','isalias_html','y');
INSERT INTO emlog_options VALUES('44','isgzipenable','n');
INSERT INTO emlog_options VALUES('45','isxmlrpcenable','n');
INSERT INTO emlog_options VALUES('46','ismobile','n');
INSERT INTO emlog_options VALUES('47','isexcerpt','y');
INSERT INTO emlog_options VALUES('48','excerpt_subnum','300');
INSERT INTO emlog_options VALUES('49','istwitter','y');
INSERT INTO emlog_options VALUES('50','istreply','n');
INSERT INTO emlog_options VALUES('51','topimg','');
INSERT INTO emlog_options VALUES('61','yls_reg_enable','y');
INSERT INTO emlog_options VALUES('52','custom_topimgs','a:0:{}');
INSERT INTO emlog_options VALUES('53','timezone','8');
INSERT INTO emlog_options VALUES('54','active_plugins','a:11:{i:0;s:27:\"tpl_options/tpl_options.php\";i:1;s:23:\"em_static/em_static.php\";i:2;s:19:\"yls_reg/yls_reg.php\";i:3;s:13:\"tips/tips.php\";i:4;s:9:\"go/go.php\";i:5;s:19:\"sitemap/sitemap.php\";i:6;s:51:\"kl_auto_backup_and_mail/kl_auto_backup_and_mail.php\";i:7;s:27:\"emlog_qzone/emlog_qzone.php\";i:9;s:29:\"themeseditor/themeseditor.php\";i:10;s:15:\"em_ad/em_ad.php\";i:11;s:19:\"duoshuo/duoshuo.php\";}');
INSERT INTO emlog_options VALUES('55','widget_title','a:13:{s:7:\"blogger\";s:12:\"个人资料\";s:8:\"calendar\";s:6:\"日历\";s:7:\"twitter\";s:12:\"最新微语\";s:3:\"tag\";s:6:\"标签\";s:4:\"sort\";s:6:\"分类\";s:7:\"archive\";s:6:\"存档\";s:7:\"newcomm\";s:12:\"最新评论\";s:6:\"newlog\";s:12:\"最新文章\";s:10:\"random_log\";s:12:\"随机文章\";s:6:\"hotlog\";s:12:\"热门文章\";s:4:\"link\";s:6:\"链接\";s:6:\"search\";s:6:\"搜索\";s:11:\"custom_text\";s:15:\"自定义组件\";}');
INSERT INTO emlog_options VALUES('56','custom_widget','a:0:{}');
INSERT INTO emlog_options VALUES('57','widgets1','a:5:{i:0;s:8:\"calendar\";i:1;s:7:\"archive\";i:2;s:7:\"newcomm\";i:3;s:4:\"link\";i:4;s:6:\"search\";}');
INSERT INTO emlog_options VALUES('58','widgets2','');
INSERT INTO emlog_options VALUES('59','widgets3','');
INSERT INTO emlog_options VALUES('60','widgets4','');
INSERT INTO emlog_options VALUES('62','duoshuo_short_name','guotougai');
INSERT INTO emlog_options VALUES('63','duoshuo_secret','13f7dea9e9b8edc150b6553040649190');
INSERT INTO emlog_options VALUES('64','duoshuo_show_original_comments','1');

DROP TABLE IF EXISTS emlog_navi;
CREATE TABLE `emlog_navi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `naviname` varchar(30) NOT NULL DEFAULT '',
  `url` varchar(75) NOT NULL DEFAULT '',
  `newtab` enum('n','y') NOT NULL DEFAULT 'n',
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  `taxis` int(10) unsigned NOT NULL DEFAULT '0',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `isdefault` enum('n','y') NOT NULL DEFAULT 'n',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `type_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO emlog_navi VALUES('1','首页','','n','n','1','0','y','1','0');
INSERT INTO emlog_navi VALUES('2','微语','t','n','y','2','0','y','2','0');
INSERT INTO emlog_navi VALUES('3','登录','admin','n','n','4','0','y','3','0');
INSERT INTO emlog_navi VALUES('4','注册','http://aimidada.com/?plugin=yls_reg','n','n','3','0','n','0','0');

DROP TABLE IF EXISTS emlog_reply;
CREATE TABLE `emlog_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned NOT NULL DEFAULT '0',
  `date` bigint(20) NOT NULL,
  `name` varchar(20) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  `ip` varchar(128) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `gid` (`tid`),
  KEY `hide` (`hide`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS emlog_sort;
CREATE TABLE `emlog_sort` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sortname` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(200) NOT NULL DEFAULT '',
  `taxis` int(10) unsigned NOT NULL DEFAULT '0',
  `pid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `template` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO emlog_sort VALUES('1','文章','th','1','0','','');

DROP TABLE IF EXISTS emlog_link;
CREATE TABLE `emlog_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sitename` varchar(30) NOT NULL DEFAULT '',
  `siteurl` varchar(75) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `hide` enum('n','y') NOT NULL DEFAULT 'n',
  `taxis` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO emlog_link VALUES('2','阿里妈妈','http://www.alimama.com/','','n','7');
INSERT INTO emlog_link VALUES('4','Aimidada','http://www.aimidada.com/','','n','0');
INSERT INTO emlog_link VALUES('5','淘宝 UED','http://ued.taobao.org/blog/','','n','2');
INSERT INTO emlog_link VALUES('6','腾讯CDC','http://cdc.tencent.com/','','n','3');
INSERT INTO emlog_link VALUES('7','百度 FEX','http://fex.baidu.com/','','n','5');
INSERT INTO emlog_link VALUES('8','微博 UDC','http://udc.weibo.com/','','n','6');
INSERT INTO emlog_link VALUES('9','360 UXC','http://uxc.360.cn/','','n','4');
INSERT INTO emlog_link VALUES('10','Easy-icon','http://www.easyicon.net/','','n','1');
INSERT INTO emlog_link VALUES('11','Cpanel aimidada','http://cpanel.aimidada.com/','','n','8');

DROP TABLE IF EXISTS emlog_tag;
CREATE TABLE `emlog_tag` (
  `tid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tagname` varchar(60) NOT NULL DEFAULT '',
  `gid` text NOT NULL,
  PRIMARY KEY (`tid`),
  KEY `tagname` (`tagname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS emlog_twitter;
CREATE TABLE `emlog_twitter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `img` varchar(200) DEFAULT NULL,
  `author` int(10) NOT NULL DEFAULT '1',
  `date` bigint(20) NOT NULL,
  `replynum` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `author` (`author`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS emlog_user;
CREATE TABLE `emlog_user` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `nickname` varchar(20) NOT NULL DEFAULT '',
  `role` varchar(60) NOT NULL DEFAULT '',
  `ischeck` enum('n','y') NOT NULL DEFAULT 'n',
  `photo` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(60) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO emlog_user VALUES('1','aimidada','$P$Bm73NjBHKJqyiv52U3jKqL7HlUs921/','','admin','n','','','');
INSERT INTO emlog_user VALUES('2','guotougai','$P$BlrDjJUZOSQIlCT3mt.RCJ9BGWfmy41','锅头盖','admin','n','','','');

DROP TABLE IF EXISTS emlog_tpl_options_data;
CREATE TABLE `emlog_tpl_options_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `template` char(64) NOT NULL,
  `name` char(64) NOT NULL,
  `depend` char(64) NOT NULL DEFAULT '',
  `data` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template` (`template`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS emlog_emstatic_cronjob;
CREATE TABLE `emlog_emstatic_cronjob` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `piror` tinyint(1) DEFAULT NULL,
  `locked` tinyint(1) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `data` varchar(200) DEFAULT NULL,
  `page` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `piror` (`id`,`piror`,`locked`,`type`,`data`,`page`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS emlog_ad;
CREATE TABLE `emlog_ad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) DEFAULT '0',
  `position` tinyint(1) unsigned DEFAULT '0',
  `title` varchar(50) DEFAULT NULL,
  `weight` tinyint(2) unsigned DEFAULT '10',
  `content` text,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `position` (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



#the end of backup